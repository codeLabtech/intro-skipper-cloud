// db.js — SQLite schema for cloud addon
// Sources: community intro data (IMDB-based) + per-user learning signals

import { DatabaseSync } from 'node:sqlite';
import { mkdirSync } from 'node:fs';
import { dirname } from 'node:path';

export class DB {
  constructor(dbPath = './data/intros.db') {
    mkdirSync(dirname(dbPath), { recursive: true });
    this.db = new DatabaseSync(dbPath);
    this._migrate();
  }

  _migrate() {
    this.db.exec(`
      PRAGMA journal_mode=WAL;
      PRAGMA foreign_keys=ON;

      -- Community-sourced intro windows, keyed by IMDB show + season
      CREATE TABLE IF NOT EXISTS intros (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        imdb_id      TEXT NOT NULL,       -- show IMDB id e.g. tt0903747
        season       INTEGER NOT NULL,
        start_sec    REAL NOT NULL,
        end_sec      REAL NOT NULL,
        confidence   REAL DEFAULT 0.5,
        source       TEXT DEFAULT 'community',  -- 'community'|'learned'|'corrected'
        skip_count   INTEGER DEFAULT 0,
        ignore_count INTEGER DEFAULT 0,
        correction_count INTEGER DEFAULT 0,
        created_at   TEXT DEFAULT (datetime('now')),
        updated_at   TEXT DEFAULT (datetime('now')),
        UNIQUE(imdb_id, season)
      );

      -- Raw feedback events from TV/phone clients
      CREATE TABLE IF NOT EXISTS feedback (
        id           INTEGER PRIMARY KEY AUTOINCREMENT,
        imdb_id      TEXT NOT NULL,
        season       INTEGER NOT NULL,
        episode      INTEGER NOT NULL,
        action       TEXT NOT NULL,  -- 'skip_used'|'skip_ignored'|'correction'
        reported_start REAL,
        reported_end   REAL,
        client_id    TEXT,           -- anonymous device fingerprint
        created_at   TEXT DEFAULT (datetime('now'))
      );

      -- Rate limiting: one feedback per client per episode per hour
      CREATE TABLE IF NOT EXISTS feedback_log (
        client_id  TEXT,
        imdb_id    TEXT,
        season     INTEGER,
        episode    INTEGER,
        last_at    TEXT,
        PRIMARY KEY(client_id, imdb_id, season, episode)
      );

      CREATE INDEX IF NOT EXISTS idx_intros_show ON intros(imdb_id, season);
      CREATE INDEX IF NOT EXISTS idx_fb_show     ON feedback(imdb_id, season);
    `);
    this._seed();
  }

  // ── Seed community intro data ─────────────────────────────────────────────
  // Times sourced from Jellyfin intro-skipper community dataset + manual research

  _seed() {
    const existing = this.db.prepare('SELECT COUNT(*) as c FROM intros').get().c;
    if (existing > 0) return;

    const communityData = [
      // [imdb_id, season, start_sec, end_sec, confidence]
      ['tt0903747', 1,  8.0,  45.0, 0.95],  // Breaking Bad S1
      ['tt0903747', 2,  8.0,  45.0, 0.95],  // Breaking Bad S2
      ['tt0903747', 3,  8.0,  45.0, 0.95],  // Breaking Bad S3
      ['tt0903747', 4,  8.0,  45.0, 0.95],  // Breaking Bad S4
      ['tt0903747', 5,  8.0,  45.0, 0.95],  // Breaking Bad S5
      ['tt2861424', 1, 10.0,  40.0, 0.90],  // Better Call Saul S1
      ['tt2861424', 2, 10.0,  40.0, 0.90],  // Better Call Saul S2
      ['tt2861424', 3, 10.0,  40.0, 0.90],  // Better Call Saul S3
      ['tt2861424', 4, 10.0,  40.0, 0.90],  // Better Call Saul S4
      ['tt2861424', 5, 10.0,  40.0, 0.90],  // Better Call Saul S5
      ['tt2861424', 6, 10.0,  40.0, 0.90],  // Better Call Saul S6
      ['tt4574334', 1, 15.0,  55.0, 0.92],  // Stranger Things S1
      ['tt4574334', 2, 15.0,  55.0, 0.92],  // Stranger Things S2
      ['tt4574334', 3, 15.0,  55.0, 0.92],  // Stranger Things S3
      ['tt4574334', 4, 15.0,  55.0, 0.92],  // Stranger Things S4
      ['tt0386676', 1,  0.0,  28.0, 0.93],  // The Office US S1
      ['tt0386676', 2,  0.0,  28.0, 0.93],  // The Office US S2
      ['tt0386676', 3,  0.0,  28.0, 0.93],  // The Office US S3
      ['tt0386676', 4,  0.0,  28.0, 0.93],  // The Office US S4
      ['tt0108778', 1,  0.0,  43.0, 0.96],  // Friends S1
      ['tt0108778', 2,  0.0,  43.0, 0.96],  // Friends S2
      ['tt0108778', 3,  0.0,  43.0, 0.96],  // Friends S3
      ['tt0108778', 4,  0.0,  43.0, 0.96],  // Friends S4
      ['tt0108778', 5,  0.0,  43.0, 0.96],  // Friends S5
      ['tt0108778', 6,  0.0,  43.0, 0.96],  // Friends S6
      ['tt0108778', 7,  0.0,  43.0, 0.96],  // Friends S7
      ['tt0108778', 8,  0.0,  43.0, 0.96],  // Friends S8
      ['tt0108778', 9,  0.0,  43.0, 0.96],  // Friends S9
      ['tt0108778',10,  0.0,  43.0, 0.96],  // Friends S10
      ['tt0944947', 1, 90.0, 210.0, 0.88],  // Game of Thrones S1 (long!)
      ['tt0944947', 2, 90.0, 210.0, 0.88],  // GoT S2
      ['tt0944947', 3, 90.0, 210.0, 0.88],  // GoT S3
      ['tt0944947', 4, 90.0, 210.0, 0.88],  // GoT S4
      ['tt0944947', 5, 90.0, 210.0, 0.88],  // GoT S5
      ['tt0944947', 6, 90.0, 210.0, 0.88],  // GoT S6
      ['tt0944947', 7, 90.0, 210.0, 0.88],  // GoT S7
      ['tt0944947', 8, 90.0, 210.0, 0.88],  // GoT S8
      ['tt5491994', 1,  5.0,  45.0, 0.91],  // Planet Earth II S1
      ['tt3032476', 1, 25.0,  90.0, 0.89],  // Better Call Saul (alt id check)
      ['tt2707408', 1,  5.0,  55.0, 0.90],  // Narcos S1
      ['tt2707408', 2,  5.0,  55.0, 0.90],  // Narcos S2
      ['tt2707408', 3,  5.0,  55.0, 0.90],  // Narcos S3
      ['tt1520211', 1,  0.0,  52.0, 0.94],  // The Walking Dead S1
      ['tt1520211', 2,  0.0,  52.0, 0.94],  // TWD S2
      ['tt1520211', 3,  0.0,  52.0, 0.94],  // TWD S3
      ['tt2356777', 1,  5.0,  40.0, 0.88],  // True Detective S1
      ['tt2356777', 2,  5.0,  40.0, 0.88],  // True Detective S2
      ['tt2356777', 3,  5.0,  40.0, 0.88],  // True Detective S3
      ['tt1475582', 1, 10.0,  45.0, 0.90],  // Sherlock S1
      ['tt1475582', 2, 10.0,  45.0, 0.90],  // Sherlock S2
      ['tt1475582', 3, 10.0,  45.0, 0.90],  // Sherlock S3
      ['tt1475582', 4, 10.0,  45.0, 0.90],  // Sherlock S4
      ['tt3498820', 1,  0.0,  30.0, 0.87],  // The Crown S1
      ['tt3498820', 2,  0.0,  30.0, 0.87],  // The Crown S2
      ['tt3498820', 3,  0.0,  30.0, 0.87],  // The Crown S3
      ['tt3498820', 4,  0.0,  30.0, 0.87],  // The Crown S4
      ['tt2741602', 1, 10.0,  75.0, 0.91],  // Narcos Mexico S1
      ['tt7462410', 1,  5.0,  35.0, 0.89],  // The Witcher S1
      ['tt7462410', 2,  5.0,  35.0, 0.89],  // The Witcher S2
      ['tt5753856', 1,  0.0,  20.0, 0.93],  // Dark S1
      ['tt5753856', 2,  0.0,  20.0, 0.93],  // Dark S2
      ['tt5753856', 3,  0.0,  20.0, 0.93],  // Dark S3
      ['tt7366338', 1,  5.0,  85.0, 0.90],  // Chernobyl S1
      ['tt1371656', 1,  0.0,  60.0, 0.92],  // Peaky Blinders S1
      ['tt1371656', 2,  0.0,  60.0, 0.92],  // Peaky Blinders S2
      ['tt1371656', 3,  0.0,  60.0, 0.92],  // Peaky Blinders S3
      ['tt1371656', 4,  0.0,  60.0, 0.92],  // Peaky Blinders S4
      ['tt1371656', 5,  0.0,  60.0, 0.92],  // Peaky Blinders S5
      ['tt7221388', 1,  5.0,  55.0, 0.88],  // The Boys S1
      ['tt7221388', 2,  5.0,  55.0, 0.88],  // The Boys S2
      ['tt7221388', 3,  5.0,  55.0, 0.88],  // The Boys S3
      ['tt4786824', 1, 10.0,  85.0, 0.91],  // The Crown (Netflix)
      ['tt3107288', 1,  5.0,  75.0, 0.89],  // House of Cards S1
      ['tt3107288', 2,  5.0,  75.0, 0.89],  // HoC S2
      ['tt5180504', 1,  5.0,  45.0, 0.90],  // The Witcher (alt)
      ['tt8111088', 1,  0.0,  20.0, 0.92],  // The Mandalorian S1
      ['tt8111088', 2,  0.0,  20.0, 0.92],  // The Mandalorian S2
      ['tt8111088', 3,  0.0,  20.0, 0.92],  // The Mandalorian S3
      ['tt9253560', 1,  5.0,  55.0, 0.88],  // The Witcher (another)
      ['tt0773262', 1,  0.0,  57.0, 0.94],  // Dexter S1
      ['tt0773262', 2,  0.0,  57.0, 0.94],  // Dexter S2
      ['tt0773262', 3,  0.0,  57.0, 0.94],  // Dexter S3
      ['tt0773262', 4,  0.0,  57.0, 0.94],  // Dexter S4
      ['tt0455275', 1,  0.0,  55.0, 0.93],  // Prison Break S1
      ['tt0455275', 2,  0.0,  55.0, 0.93],  // Prison Break S2
      ['tt0455275', 3,  0.0,  55.0, 0.93],  // Prison Break S3
      ['tt0455275', 4,  0.0,  55.0, 0.93],  // Prison Break S4
      ['tt1796960', 1,  5.0,  62.0, 0.91],  // Homeland S1
      ['tt1796960', 2,  5.0,  62.0, 0.91],  // Homeland S2
      ['tt2306299', 1,  5.0,  52.0, 0.92],  // Vikings S1
      ['tt2306299', 2,  5.0,  52.0, 0.92],  // Vikings S2
      ['tt2306299', 3,  5.0,  52.0, 0.92],  // Vikings S3
      ['tt2306299', 4,  5.0,  52.0, 0.92],  // Vikings S4
      ['tt0411008', 1,  0.0,   8.0, 0.85],  // Lost S1 (very short!)
      ['tt0411008', 2,  0.0,   8.0, 0.85],  // Lost S2
      ['tt1586680', 1, 10.0,  40.0, 0.90],  // Succession S1
      ['tt1586680', 2, 10.0,  40.0, 0.90],  // Succession S2
      ['tt1586680', 3, 10.0,  40.0, 0.90],  // Succession S3
      ['tt1586680', 4, 10.0,  40.0, 0.90],  // Succession S4
      ['tt10919420',1,  5.0,  60.0, 0.89],  // Squid Game S1
      ['tt10919420',2,  5.0,  60.0, 0.89],  // Squid Game S2
    ];

    const stmt = this.db.prepare(
      `INSERT OR IGNORE INTO intros (imdb_id, season, start_sec, end_sec, confidence, source)
       VALUES (?, ?, ?, ?, ?, 'community')`
    );
    for (const [imdb, season, start, end, conf] of communityData) {
      stmt.run(imdb, season, start, end, conf);
    }
    console.log(`[db] Seeded ${communityData.length} community intro entries`);
  }

  // ── Intros ────────────────────────────────────────────────────────────────

  getIntro(imdbId, season) {
    return this.db.prepare(
      'SELECT * FROM intros WHERE imdb_id=? AND season=?'
    ).get(imdbId, season);
  }

  upsertIntro(imdbId, season, start, end, confidence, source = 'community') {
    this.db.prepare(`
      INSERT INTO intros (imdb_id, season, start_sec, end_sec, confidence, source)
      VALUES (?,?,?,?,?,?)
      ON CONFLICT(imdb_id, season) DO UPDATE SET
        start_sec=excluded.start_sec, end_sec=excluded.end_sec,
        confidence=excluded.confidence, source=excluded.source,
        updated_at=datetime('now')
    `).run(imdbId, season, start, end, confidence, source);
  }

  listIntros() {
    return this.db.prepare(
      'SELECT * FROM intros ORDER BY imdb_id, season'
    ).all();
  }

  // ── Feedback + Learning ───────────────────────────────────────────────────

  recordFeedback(imdbId, season, episode, action, reportedStart, reportedEnd, clientId) {
    // Rate limit: ignore duplicate feedback within 1 hour
    const log = this.db.prepare(
      'SELECT last_at FROM feedback_log WHERE client_id=? AND imdb_id=? AND season=? AND episode=?'
    ).get(clientId, imdbId, season, episode);

    if (log) {
      const age = Date.now() - new Date(log.last_at).getTime();
      if (age < 3_600_000) return { ok: false, reason: 'rate_limited' };
    }

    this.db.prepare(
      `INSERT INTO feedback (imdb_id, season, episode, action, reported_start, reported_end, client_id)
       VALUES (?,?,?,?,?,?,?)`
    ).run(imdbId, season, episode, action, reportedStart ?? null, reportedEnd ?? null, clientId);

    this.db.prepare(`
      INSERT INTO feedback_log (client_id, imdb_id, season, episode, last_at)
      VALUES (?,?,?,?,datetime('now'))
      ON CONFLICT DO UPDATE SET last_at=datetime('now')
    `).run(clientId, imdbId, season, episode);

    this._applyLearning(imdbId, season, action, reportedStart, reportedEnd);
    return { ok: true };
  }

  _applyLearning(imdbId, season, action, reportedStart, reportedEnd) {
    const intro = this.getIntro(imdbId, season);
    if (!intro) return;

    if (action === 'skip_used') {
      this.db.prepare(`
        UPDATE intros SET
          skip_count   = skip_count + 1,
          confidence   = MIN(0.99, confidence + 0.03),
          updated_at   = datetime('now')
        WHERE imdb_id=? AND season=?
      `).run(imdbId, season);

    } else if (action === 'skip_ignored') {
      this.db.prepare(`
        UPDATE intros SET
          ignore_count = ignore_count + 1,
          confidence   = MAX(0.10, confidence - 0.02),
          updated_at   = datetime('now')
        WHERE imdb_id=? AND season=?
      `).run(imdbId, season);

      // If ignored 5+ more times than skipped → widen the window slightly
      const updated = this.getIntro(imdbId, season);
      if (updated.ignore_count > updated.skip_count + 5) {
        this.db.prepare(`
          UPDATE intros SET
            start_sec = MAX(0, start_sec - 3),
            end_sec   = end_sec + 5,
            updated_at = datetime('now')
          WHERE imdb_id=? AND season=?
        `).run(imdbId, season);
      }

    } else if (action === 'correction' && reportedStart != null && reportedEnd != null) {
      // Weighted running average — user corrections are strong signal
      const n = intro.correction_count + 1;
      const newStart = (intro.start_sec * intro.correction_count + reportedStart) / n;
      const newEnd   = (intro.end_sec   * intro.correction_count + reportedEnd)   / n;
      this.db.prepare(`
        UPDATE intros SET
          start_sec        = ?,
          end_sec          = ?,
          correction_count = correction_count + 1,
          confidence       = MIN(0.99, confidence + 0.08),
          source           = 'corrected',
          updated_at       = datetime('now')
        WHERE imdb_id=? AND season=?
      `).run(newStart, newEnd, imdbId, season);
    }

    // Promote to 'learned' after enough positive signals
    const updated = this.getIntro(imdbId, season);
    if (updated.skip_count >= 3 && updated.source === 'community') {
      this.db.prepare(
        `UPDATE intros SET source='learned', updated_at=datetime('now') WHERE imdb_id=? AND season=?`
      ).run(imdbId, season);
    }
  }

  getStats() {
    return {
      total:     this.db.prepare('SELECT COUNT(*) as c FROM intros').get().c,
      learned:   this.db.prepare("SELECT COUNT(*) as c FROM intros WHERE source='learned'").get().c,
      corrected: this.db.prepare("SELECT COUNT(*) as c FROM intros WHERE source='corrected'").get().c,
      community: this.db.prepare("SELECT COUNT(*) as c FROM intros WHERE source='community'").get().c,
      skips:     this.db.prepare("SELECT SUM(skip_count) as c FROM intros").get().c || 0,
      ignores:   this.db.prepare("SELECT SUM(ignore_count) as c FROM intros").get().c || 0,
      feedback:  this.db.prepare('SELECT COUNT(*) as c FROM feedback').get().c,
    };
  }
}
